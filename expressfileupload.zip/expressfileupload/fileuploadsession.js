var express=require("express")
var app=express()

app.use(express.urlencoded({extended:true}))
app.use(express.json())

const {MongoClient}=require("mongodb")
var url="mongodb://127.0.0.1:27017"

app.get("/",function(req,res){
    res.sendFile(__dirname+"/homepage.html")
})

app.get("/loginform",function(req,res){
    res.sendFile(__dirname+"/.html")
})

app.get("/postman",function(req,res){
    MongoClient.connect(url,function(err,conn){
        var db=conn.db("delta")
            db.collection("students").find().toArray(function(err,data){
            res.send(data)})
})
})

app.listen(8090,function(req,res){
console.log("lisening on 8090")
})