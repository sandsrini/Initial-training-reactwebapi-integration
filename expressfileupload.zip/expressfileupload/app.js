var express=require("express")
var app=express()
var path=require("path")
const multer=require("multer")

const storage = multer.diskStorage({
    destination:function(req,file,cb){
    cb(null,__dirname+"/upload")
},
filename:function(req,file,cb){
console.log("file",file)
var fileext=path.extname(file.originalname);
const uniqueSuffix = Date.now() + "-" + Math.round(Math.random()*1E9)
cb(null,file.fieldname + "-" + uniqueSuffix + fileext)
}
})

const upload=multer({storage:storage})

app.use(express.urlencoded({extended:true}))
app.use(express.json())

app.get("/",function(req,res){
    res.send("hello upload your file")
})

app.get("/regform",function(req,res){
res.sendFile(__dirname+"/regform.html")
})

app.post("/sturegister",upload.single("profilepic"),function(req,res){
res.send("Check your folder")
console.log("data",req.body)
})

app.listen(8090,function(req,res){
console.log("welcome")
})