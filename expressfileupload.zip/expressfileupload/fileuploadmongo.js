var express = require("express")
var app = express()
// var stds=[]
var path = require("path")
const multer = require("multer")

const { MongoClient, ObjectId } = require("mongodb")
var url = "mongodb://127.0.0.1:27017"

app.use(express.urlencoded({ extended: true }))
app.use(express.json())

app.set('view engine', 'pug');
app.set('views', './views');

app.use(express.static('upload'));

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, __dirname + "/upload")
    },
    filename: function (req, file, cb) {
        console.log("file", file)
        var fileext = path.extname(file.originalname);
        const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + "-" + uniqueSuffix + fileext)
    }
})
const upload = multer({ storage: storage })

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/fileuploadform.html")
})
app.post("/sturegmongo", upload.single("profilepic"), function (req, res) {

    console.log("req.file", req.file)
    req.body.profilepic = req.file.filename
    console.log(req.body)
    MongoClient.connect(url, function (err, conn) {
        var db = conn.db("delta")
        db.collection("students").insertOne(req.body, function (err, data) {
            res.send(data)
            // res.render("fileuploadpug",{alldata:data})
        })
    })
})
app.get("/render1", function (req, res) {
    MongoClient.connect(url, function (err, conn) {
        var db = conn.db("delta")
        db.collection("students").find().toArray(function (err, data) {
            // res.render("fileuploadpug", { alldata: data })
            res.send(data)
        })
    })
})
app.get("/rg/:id", function (req, res) {
    MongoClient.connect(url, function (err, conn) {
        var db = conn.db("delta")
        db.collection("students").find({ _id: ObjectId(req.params.id) }).toArray(function (err, data) {
            res.render("singleviewpug", { alldata1: data })
        })
    })
})
app.get("/delete/:id", function (req, res) {
    MongoClient.connect(url, function (err, conn) {
        var db = conn.db("delta")
        db.collection("students").deleteOne({ _id: ObjectId(req.params.id) }, function (err, data) {
            res.redirect("/render1")
        })
    })
})
app.post("/updpic1", upload.single("profilepic"), function (req, res) {
    console.log("req.file", req.file)
    req.body.profilepic = req.file.filename
    console.log(req.body)
    MongoClient.connect(url, function (err, conn) {
        var db = conn.db("delta")
        db.collection("students").updateOne({ _id: ObjectId(req.body.id) }, {
            $set:
            {
                profilepic: req.body.profilepic
            }
        })
    })
    res.send("hello")
    // , function (err, data) {
    //     if (err) {
    //         res.send(err)
    //     }
    //     else {
    //         res.send("hello")
    //     }
    })

app.get("/updpic2/:id", function (req, res) {
    res.render("updpicpug", { id: req.params.id })
    // res.sendFile(__dirname+"/uploadpic.html")
})

app.listen(8090, function (req, res) {
    console.log("listening on 8090")
})