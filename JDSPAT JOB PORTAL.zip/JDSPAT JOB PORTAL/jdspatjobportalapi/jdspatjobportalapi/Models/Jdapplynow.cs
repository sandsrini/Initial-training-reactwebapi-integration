﻿using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace jdspatjobportalapi.Models
{
    public partial class Jdapplynow
    {
        [Key]
   
        public int ApplyId { get; set; }
        [Required]
        [StringLength(25)]
        [RegularExpression(@"^(([A-za-z]+[\s]{1}[A-za-z]+)|([A-Za-z]+))$")]
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        public string UserEmail { get; set; }
        [Required]
      
        [Url(ErrorMessage = "Please enter a valid url")]


        public string Link { get; set; }
        [Required]
        public string Resume { get; set; }
        [Required]
        public string Letter { get; set; }
        


        public virtual string Id  { get; set; }//dependent key
        [ForeignKey("Id")]
        public virtual  ApplicationUser userid { get; set; }//navigation property

        public virtual int JobDetailsId { get; set; }//dependent key
        [ForeignKey("JobDetailsId")]
        public virtual JobDetail JobId { get; set; }//navigation property
    }
}


