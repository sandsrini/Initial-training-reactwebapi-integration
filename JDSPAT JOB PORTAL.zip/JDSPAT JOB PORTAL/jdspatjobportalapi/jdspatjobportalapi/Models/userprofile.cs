﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using System.Linq;
using System.Threading.Tasks;

namespace jdspatjobportalapi.Models
{
    public class userprofile
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int details_id { get; set; }
        [Required]
        public string Work { get; set; }
        [Required]
        public string education { get; set; }
        [Required]
        public string skills { get; set; }
        [Required]
        public string experience { get; set; }
        [Required]
        public string profile_summary { get; set; }
        public string resume { get; set; }


      

        public virtual string Id { get; set; }//dependent key
        [ForeignKey("Id")]
        public virtual ApplicationUser user_reg { get; set; }//navigation property
    }
}
