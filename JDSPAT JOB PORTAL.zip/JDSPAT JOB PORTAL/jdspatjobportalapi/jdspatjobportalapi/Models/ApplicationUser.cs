﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace jdspatjobportalapi.Models
{
    public class ApplicationUser : IdentityUser
    {

        public virtual Jdapplynow jobapply { get; set; }
        public virtual JobDetail jobdetailss { get; set; }
        public virtual userprofile profiles { get; set; }


        public string Address { get; set; }
        public string Gender { get; set; }
        public string SecurityQuest { get; set; }
        public string SecurityAns { get; set; }
        public string pass { get; set; }
        public string CompanyName { get; set; }
        public string CompanyAddress { get; set; }
        public string Employerrole { get; set; }

    }
}
