﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace jdspatjobportalapi.Models
{
    public partial class JobDetail
    {
        [Key]
        public int JobDetailsId { get; set; }
        [Required]
        public string Companyname { get; set; }
        [Required]
        public string JobCategory { get; set; }
        [Required]
        public string Requiredskills { get; set; }
        [Required]
        public string Experience { get; set; }
        [Required]
        public int NoOfVacancies { get; set; }
        [Required]
        public double Salary { get; set; }
        [Required]
        public DateTime EndDate { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public string JobLocation { get; set; }
        [Required]
        public double PhNo { get; set; }
        [Required]
        public string CompanyAddress { get; set; }
        [Required]
        public string JobDescription { get; set; }
        [Required]
        public string JobType { get; set; }

        

        public virtual string Id { get; set; }//dependent key
        [ForeignKey("Id")]
        public virtual ApplicationUser Employer { get; set; }//navigation property
    }
}
