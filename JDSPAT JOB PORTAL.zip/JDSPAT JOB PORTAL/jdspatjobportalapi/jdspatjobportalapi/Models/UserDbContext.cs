﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace jdspatjobportalapi.Models
{
    public class UserDbContext: IdentityDbContext<ApplicationUser>
    {

        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
           
        }


        public DbSet<Contact> Contacts { get; set; }

        public DbSet<Jdapplynow> jobapply { get; set; }

        public DbSet<userprofile> profiles { get; set; }

        public DbSet<JobDetail> jobdetailss { get; set; }






    }
}
