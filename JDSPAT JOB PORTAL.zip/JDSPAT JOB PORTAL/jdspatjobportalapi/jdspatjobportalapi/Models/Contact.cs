﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace jdspatjobportalapi.Models
{
    public partial class Contact
    {
        [Key]
        public int ContactId { get; set; }
        [Required]
        [StringLength(25)]
        [RegularExpression(@"^(([A-za-z]+[\s]{1}[A-za-z]+)|([A-Za-z]+))$")]
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        public string Emailid { get; set; }
        [Required]

        [StringLength(200)]

        public string Message { get; set; }
    }
}
