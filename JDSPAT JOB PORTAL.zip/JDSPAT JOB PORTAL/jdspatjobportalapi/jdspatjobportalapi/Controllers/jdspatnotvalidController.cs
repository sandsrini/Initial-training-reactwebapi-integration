﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using jdspatjobportalapi.Models;
using Microsoft.EntityFrameworkCore;

namespace jdspatjobportalapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class jdspatnotvalidController : ControllerBase
    {
        private readonly UserDbContext _context;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<JobDetail>>> GetJobDetails()
        {
            return await _context.jobdetailss.ToListAsync();
        }

      

       

    }
}
