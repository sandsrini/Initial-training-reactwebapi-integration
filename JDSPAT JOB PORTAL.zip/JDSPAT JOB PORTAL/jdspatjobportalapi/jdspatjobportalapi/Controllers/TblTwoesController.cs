﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using jdspatjobportalapi.Models;

namespace jdspatjobportalapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TblTwoesController : ControllerBase
    {
        private readonly UserDbContext _context;

        public TblTwoesController(UserDbContext context)
        {
            _context = context;
        }

        // GET: api/TblTwoes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<userprofile>>> GetMainDetailsTbl()
        {
            return await _context.profiles.ToListAsync();
        }

        // GET: api/TblTwoes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<userprofile>> GetTblTwo(int id)
        {
            var tblTwo = await _context.profiles.FindAsync(id);


            //var tblTwo = _context.MainDetailsTbl.Include(reg => reg.user_reg)
            //     .Where(reg => reg.user_id == id).FirstOrDefault();


            if (tblTwo == null)
            {
                return NotFound();
            }

            return tblTwo;
        }

        // PUT: api/TblTwoes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTblTwo(int id, userprofile tblTwo)
        {
            if (id != tblTwo.details_id)
            {
                return BadRequest();
            }

            _context.Entry(tblTwo).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TblTwoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TblTwoes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<userprofile>> PostTblTwo(userprofile tblTwo)
        {
            _context.profiles.Add(tblTwo);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTblTwo", new { id = tblTwo.details_id }, tblTwo);
        }

        // DELETE: api/TblTwoes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTblTwo(int id)
        {
            var tblTwo = await _context.profiles.FindAsync(id);
            if (tblTwo == null)
            {
                return NotFound();
            }

            _context.profiles.Remove(tblTwo);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TblTwoExists(int id)
        {
            return _context.profiles.Any(e => e.details_id == id);
        }
    }
}
