﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using jdspatmvc.Models;
using jdspatmvc.Helper;
using System.Text;

namespace jdspatmvc.Controllers
{
    public class loginController : Controller
    {
        private readonly ILogger<loginController> _logger;

        public loginController(ILogger<loginController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult createUser()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> createUser(Userreg newuser)
        {
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(newuser), Encoding.UTF8, "application/json");
                using (var response = await httpClient.PostAsync("https://localhost:44341/api/Authenticate/register", content))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        return Redirect("~/login/Index");
                    }
                    return Redirect("~/login/createUser");
                }

            }

        }

        public IActionResult createEmployer()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> createEmployer(EmployerUser newuser)
        {
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(newuser), Encoding.UTF8, "application/json");
                using (var response = await httpClient.PostAsync("https://localhost:44341/api/Authenticate/register-admin", content))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        return Redirect("~/Jobdetail/Index");
                    }
                    return Redirect("~/login/createEmployer");
                }

            }

        }

        [HttpPost]
        public async Task<IActionResult> LoginUser(Userreg user)
        {
            string msg = "";
            using (var httpClient = new HttpClient())
            {


               
                StringContent content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
                using (var response = await httpClient.PostAsync("https://localhost:44341/api/Authenticate/login", content))
                {
                    System.Diagnostics.Debug.WriteLine(response);
                    string token = await response.Content.ReadAsStringAsync();
                    System.Diagnostics.Debug.WriteLine(token);



                    if (token == "Invalid")
                    {
                        msg = "Incorrect UserID or Password!";
                        TempData["ErrorMessage"] = msg;

                        return RedirectToAction("Index");
                       
                    }
                    HttpContext.Session.SetString("JwToken", token);
                   
                    return Redirect("~/profile/Details");
                }

            }
        }

        public IActionResult Logoff()
        {
            HttpContext.Session.Clear();
            return Redirect("~/Home/home");
        }

       
    }
}
