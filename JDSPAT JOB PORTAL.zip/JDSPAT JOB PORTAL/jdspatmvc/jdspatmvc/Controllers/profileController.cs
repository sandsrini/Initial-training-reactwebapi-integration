﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using jdspatmvc.Helper;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using jdspatmvc.Models;

namespace jdspatmvc.Controllers
{
    public class profileController : Controller
    {


        jdspathelper _api = new jdspathelper();

        public async Task<IActionResult> Index()
        {
            List<userprofile> studentDatas = new List<userprofile>();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync("api/TblTwoes");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                studentDatas = JsonConvert.DeserializeObject<List<userprofile>>(res);
            }
            return View(studentDatas);
        }
        public async Task<IActionResult> Details(int id)
        {
            var std1 = new Userreg();
            var profile = new userprofile();
            HttpClient cli = _api.Initial();
            //HttpResponseMessage result2 = await cli.GetAsync($"api/TblOnes/{id}");
            HttpResponseMessage result = await cli.GetAsync($"api/TblTwoes/{id}");
            if (result.IsSuccessStatusCode)
            {
                //var res2 = result2.Content.ReadAsStringAsync().Result;
                var res = result.Content.ReadAsStringAsync().Result;

                //std1 = JsonConvert.DeserializeObject<Userreg>(res2);
                profile = JsonConvert.DeserializeObject<userprofile>(res);
            }
            //ViewData["Datafullname"] = std1.Name;
            //ViewData["Dataemail"] = std1.Email;
            //ViewData["Datamobile"] = std1.Phone;
            //ViewData["Datadob"] = std1.Dob;
            //ViewData["Dataaddress"] = std1.Address;
            //ViewData["Datagender"] = std1.Gender;
            return View(profile);
        }

        public ActionResult Create()
        {
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> Create(userprofile student)
        {
            HttpClient cli = _api.Initial();
            string authornew = JsonConvert.SerializeObject(student);
            StringContent content = new StringContent(authornew, Encoding.UTF8, "application/json");
            HttpResponseMessage response = cli.PostAsync(cli.BaseAddress + "api/TblTwoes", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("ViewAll");
            }
            return View();

        }
        public async Task<ActionResult> Delete(int id)
        {
            HttpClient cli = _api.Initial();
            HttpResponseMessage response = cli.DeleteAsync("api/TblTwoes/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("ViewAll");
            }
            return View();


        }
        public async Task<IActionResult> Edit(int id)
        {
            HttpClient cli = _api.Initial();
            var std1 = new Userreg();
            userprofile stud = new userprofile();
            //HttpResponseMessage result2 = await cli.GetAsync($"api/TblOnes/{id}");
            HttpResponseMessage response = await cli.GetAsync($"api/TblTwoes/{id}");

            if (response.IsSuccessStatusCode)
            {
                //var res2 = result2.Content.ReadAsStringAsync().Result;
                string data = response.Content.ReadAsStringAsync().Result;
                //std1 = JsonConvert.DeserializeObject<Userreg>(res2);
                stud = JsonConvert.DeserializeObject<userprofile>(data);
            }
            //ViewData["Datafullname"] = std1.Name;
            //ViewData["Dataemail"] = std1.Email;
            //ViewData["Datamobile"] = std1.Phone;
            //ViewData["Datadob"] = std1.Dob;
            //ViewData["Dataaddress"] = std1.Address;


            //ViewData["Datagender"] = std1.g;
            return View(stud);

        }
        [HttpPost]
        public async Task<IActionResult> Edit(int id, [Bind("details_id,Work,education,skills,experience,profile_summary,resume")] userprofile model)
        {
            if (id != model.details_id)
            {
                return NotFound();
            }
            HttpClient cli = _api.Initial();
            string stnew = JsonConvert.SerializeObject(model);
            StringContent content = new StringContent(stnew, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await cli.PutAsync($"api/TblTwoes/{id}", content);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Details");
            }
            return View();
        }
    }
}
