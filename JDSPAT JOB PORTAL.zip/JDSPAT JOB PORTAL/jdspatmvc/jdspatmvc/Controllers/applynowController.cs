﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using jdspatmvc.Helper;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using jdspatmvc.Models;

namespace jdspatmvc.Controllers
{
    public class applynowController : Controller
    {

        jdspathelper _api = new jdspathelper();
        
       
        public async Task<ActionResult> CreateAsync(int id)
        {
            var _jobid = new Jdapplynow();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync($"api/JobDetails/{id}");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                _jobid = JsonConvert.DeserializeObject<Jdapplynow>(res);
                ViewData["id"] = _jobid.JobDetailsId;
            }
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> Create(Jdapplynow student)
        {
            HttpClient cli = _api.Initial();
            string authornew = JsonConvert.SerializeObject(student);
            StringContent content = new StringContent(authornew, Encoding.UTF8, "application/json");
            HttpResponseMessage response = cli.PostAsync(cli.BaseAddress + "api/Jdapplynows", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();

        }
        public async Task<IActionResult> Details(int id)
        {
            var student = new JobDetail();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync($"api/JobDetails/{id}");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                student = JsonConvert.DeserializeObject<JobDetail>(res);
            }
            return View(student);
        }

        public async Task<IActionResult> Index()
        {
            List<JobDetail> studentDatas = new List<JobDetail>();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync("api/jobDetails");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                studentDatas = JsonConvert.DeserializeObject<List<JobDetail>>(res);
            }


            return View(studentDatas);
        }

    }
}
