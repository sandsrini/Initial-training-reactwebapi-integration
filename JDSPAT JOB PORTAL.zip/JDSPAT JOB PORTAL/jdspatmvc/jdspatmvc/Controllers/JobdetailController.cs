﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using jdspatmvc.Helper;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using jdspatmvc.Models;
using System.Text;
using System.Diagnostics;

namespace jdspatmvc.Controllers
{
    public class JobdetailController : Controller
    {


        jdspathelper _api = new jdspathelper();
     
        public async Task<IActionResult> JobList()
        {
            List<JobDetail> jobDatas = new List<JobDetail>();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync("api/JobDetails");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                jobDatas = JsonConvert.DeserializeObject<List<JobDetail>>(res);
            }


            return View(jobDatas);
        }
        public async Task<IActionResult> Details(int id)
        {
            var job = new JobDetail();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync($"api/JobDetails/{id}");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                job = JsonConvert.DeserializeObject<JobDetail>(res);
            }
            return View(job);
        }
        public ActionResult create()
        {
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> create(JobDetail student)
        {
            HttpClient cli = _api.Initial();
            string jobnew = JsonConvert.SerializeObject(student);
            StringContent content = new StringContent(jobnew, Encoding.UTF8, "application/json");
            HttpResponseMessage response = cli.PostAsync(cli.BaseAddress + "api/JobDetails", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("JobList");
            }
            return View();

        }
        public async Task<ActionResult> Delete(int id)
        {
            HttpClient cli = _api.Initial();
            HttpResponseMessage response = cli.DeleteAsync("api/JobDetails/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("JobList");
            }
            return View();


        }
        public async Task<IActionResult> Edit(int id)
        {
            HttpClient cli = _api.Initial();
            JobDetail job = new JobDetail();
            HttpResponseMessage response = await cli.GetAsync($"api/JobDetails/{id}");

            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                job = JsonConvert.DeserializeObject<JobDetail>(data);
            }
            return View(job);

        }
        [HttpPost]
        public async Task<IActionResult> Edit(int id, [Bind("JobDetailsId,Companyname,JobCategory,Requiredskills,Experience,NoOfVacancies,Salary,EndDate,Email,JobLocation,PhNo,CompanyAddress,JobDescription,JobType")] JobDetail model)
        {
            //if (id != model.JobDetailsId)
            //{
            //    return NotFound();
            //}
            HttpClient cli = _api.Initial();
            string stnew = JsonConvert.SerializeObject(model);
            StringContent content = new StringContent(stnew, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await cli.PutAsync($"api/JobDetails/{id}", content);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Details");
            }
            return View();
        }



        public IActionResult Privacy()
        {
            return View();
        }

        public async Task<IActionResult> Index()
        {
            List<Contact> studentDatas = new List<Contact>();
            List<JobDetail> jobDatas = new List<JobDetail>();
            List<Jdapplynow> applyDatas = new List<Jdapplynow>();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync("api/Contact");
            HttpResponseMessage result1 = await cli.GetAsync("api/JobDetails");
            HttpResponseMessage result2 = await cli.GetAsync("api/Jdapplynows");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                var res1 = result1.Content.ReadAsStringAsync().Result;
                var res2 = result2.Content.ReadAsStringAsync().Result;
                studentDatas = JsonConvert.DeserializeObject<List<Contact>>(res);
                jobDatas = JsonConvert.DeserializeObject<List<JobDetail>>(res1);
                applyDatas = JsonConvert.DeserializeObject<List<Jdapplynow>>(res2);
            }
            var totalcount = studentDatas.Count();
            ViewData["count"] = totalcount;
            var totaljob = jobDatas.Count();
            ViewData["jobcount"] = totaljob;
            var totaljobapply = applyDatas.Count();
            ViewData["applycount"] = totaljobapply;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
