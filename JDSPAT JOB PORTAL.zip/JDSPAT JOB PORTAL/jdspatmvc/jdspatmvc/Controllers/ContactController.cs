﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using jdspatmvc.Helper;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using jdspatmvc.Models;

namespace jdspatmvc.Controllers
{
    public class ContactController : Controller
    {
        jdspathelper _api = new jdspathelper();
        public ActionResult contact()
        {
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> contact(Contact contact)
        {
            HttpClient cli = _api.Initial();
            string contactnew = JsonConvert.SerializeObject(contact);
            StringContent content = new StringContent(contactnew, Encoding.UTF8, "application/json");
            HttpResponseMessage response = cli.PostAsync(cli.BaseAddress + "api/Contacts", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("contact");
            }
            return View();

        }



    }
}
