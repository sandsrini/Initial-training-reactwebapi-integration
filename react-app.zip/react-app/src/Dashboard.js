
import { BrowserRouter as Router, Switch,Route } from 'react-router-dom';
import Sidebar from './Sidebar'
import Employee from './Employee'
import Products from './Products'

function Dashboard() {
    return (
        <div>
        <Router>
        
            {/* <Sidebar/> */}
            
                <Switch>
                    
                    <Route pathname="/employee" component={Employee}/>
                    <Route pathname="/products" component={Products}/>

                </Switch>
                
        </Router>
        </div>

    );
}

export default Dashboard;
