import React,{useState,useEffect} from 'react'
import axios from 'axios';

function Putapi() {
    const [userId, setid] = useState(11)
    const [Username, setUname] = useState("UserD")
    const [Password, setpwd] = useState("User@1234")
    const [Name, setname] = useState("UserC")
    const [Age, setage] = useState(70)
    const [Mobile, setmobile] = useState("9854466789")
    const [Email, setmail] = useState("user@gmail.com")
    const [Address, setaddress] = useState("chennai")
    const [State, setstate] = useState("Tamil nadu")
    const [Pincode, setpincode] = useState("600053")
    const [Country, setcountry] = useState("India")
    const [userAddressid, setuserAddressid] = useState(11)
    const [data, setdata] = useState()

    useEffect(() => {
    put()
    
    }, [])
    const put=()=>{
        try{
        console.log(userId,Username,Password,Name,Age,Mobile,Email,Address,State,Pincode,Country,userAddressid)
        axios.put("http://localhost:21645/api/userRegistration/PostuserDetails",{userId,Username,Password,Name,Age,Mobile,Email,Address,State,Pincode,Country,userAddressid}).
        then((req)=>{
            //setdata(req.body.data);
        console.log("put",req.data);
        })}
        catch(e){
            console.log("error",e)
        }
        }
    return (
        <div>
            
        </div>
    )
}

export default Putapi
