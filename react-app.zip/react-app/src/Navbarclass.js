import React from 'react'
// import './login.css';
//import { useHistory } from 'react-router-dom';
import { BrowserRouter,Link } from 'react-router-dom';
import Content from './Content'

export default function Navbarclass(props) {
    // const[a,setA]=React.useState("")
    //const history=useHistory();
        return (
          
              <nav class="nav justify-content-right bg-dark"> 
                <Link to ="/dashboard" class="p-3">
                  <i class="fas fa-bars"></i>
                </Link>
                <h2 class="p-3 text-white">Dashboard</h2>
                <Link to="/dashboard" class="nav-link p-3">Home</Link>
                <Link to="/dashboard" class="nav-link p-3">Offers</Link>
                <br/>
                <Content/>
               </nav> 
        )
}
