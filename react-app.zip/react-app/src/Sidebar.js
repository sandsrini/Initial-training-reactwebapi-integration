import React from 'react'
import { Link} from 'react-router-dom'

function Sidebar() {

    return (
        <div>
            
                <b><Link to="/employee">Employee</Link></b>
                <br/>
                <b><Link to="/products">Products</Link></b>
        </div>
    )
}

export default Sidebar
