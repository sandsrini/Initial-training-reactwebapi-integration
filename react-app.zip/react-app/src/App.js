
import './App.css';
import Login from './Login';
import Dashboard from './Dashboard';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import Employee from './Employee';
import Products from './Products';
import Getapi from './Getapi';
import Postapi from './Postapi';
import Putapi from './Putapi';
import Deleteapi from './Deleteapi';



function App() {


  return (
    <>
    <Getapi/>
    {/* k<Postapi/> */}
    {/* <Putapi/> */}
    <Deleteapi/>

      {/* <Router>

        <Switch>
          
          <Route path="/employee" component={Employee} />
          <Route path="/products" component={Products} />
          <Route path="/logout" component={Login} />
          <Route exact path="/dashboard" component={Dashboard} />
          <Route exact path="/" component={Login} />
          
          
        </Switch>
      </Router> */}


      {/* <Routes>
          
          old version pattern new version pattern
        <Route path="/login" element={<Login />} />
          <Route exact path="/dashboard" element={<Dashboard />} />
          <Route exact path="/details" element={<Details />} />
        </Routes> */}


    </>
  );
}

export default App;
