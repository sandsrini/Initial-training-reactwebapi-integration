import React, { useEffect, useState } from 'react'
import axios from 'axios';
import './App.css'
import Navbarclass from './Navbarclass'
import Sidebar from './Sidebar';
import { Route, BrowserRouter, Switch } from 'react-router-dom';
import Products from './Products';

// import { useHistory } from 'react-router-dom';

function Employee() {
  // const navigate=useNavigate();
// const history=useHistory();

  //var test=[];
// const[ekey,setkey]=useState([]);
  const [data, setData] = useState([])

  useEffect(() => {
    axios.get("https://hub.dummyapis.com/employee?noofRecords=10&idStarts=1001")
      .then((res) => { 
        setData(res.data);
      // keyf();
    })
  },[])

  // useEffect(() => {
  //   fetchdata().then(res => { 
  //       setData(res.data);
  //     });
  // },[])

  // const keyf=()=>{
  //   var k=Object.keys(data[0])
  // setkey(k)
  // }
//   const headers=({ekey})=>{
//     const c=React.Chidren.toArray(ekey).filter(Boolean)
//     return <th>{c}</th>
// }
  // function Employee() {return axios.get("https://hub.dummyapis.com/employee?noofRecords=10&idStarts=1001")
  //     .then((res) => { 
  //       setData(res.data);
  //       console.log(res.data);
  //       //test=JSON.stringify(res.data);  
  //     setData({data:res.data});
  //      //console.log(test)
  //      console.log("data",data)
  //      });}
      // const fetchdata=async()=>{
      //   const result=await axios("https://hub.dummyapis.com/employee?noofRecords=10&idStarts=1001");
      //   // .then((res) => { 
      //   //   setData(res.data);})
      // return result;}
      
  return (
    <div>
    {/* <p>{JSON.stringify(data, null, 2)}</p>
    <p>{JSON.stringify(key,null,2)}</p> */}
    {/* <pre>
        <code> {JSON.stringify(data, null, 2)} </code>
      </pre> */}
        {/* <button onClick={()=>{navigate("Details")}}>Click</button> */}
        <div>
          {/* <BrowserRouter> */}
          <Navbarclass/>
          <Sidebar/>
          
            {/* <Switch>
              <Route path="/products" component={Products}/>
            </Switch>
          </BrowserRouter> */}
        <table class="container">

          {/* {ekey.map((i)=><th key={i}>{i}</th>)} */}

          {/* {data.map((i)=><tr key={i}>{i}</tr>)} */}

<th>
  <tr>
    <td>Id</td>
    
    <td>FirstName</td>
    <td>LastName</td>
    <td>Email</td>
    <td>ContactNumber</td>
    <td>Age</td>
    <td>Dob</td>
    <td>Salary</td>
    <td>Address</td>
  </tr>
</th>
          {data.map((item)=>{
            return (
            <tr key={item}>
              <td>{item.id}</td>
              {/* <td>{item.imageUrl}</td> */}
              <td>{item.firstName}</td>
              <td>{item.lastName}</td>
              <td>{item.email}</td>
              <td>{item.contactNumber}</td>
              <td>{item.age}</td>
              <td>{item.dob}</td>
              <td>{item.salary}</td>
              <td>{item.address}</td>
          </tr>
        )})} 
            </table>
            
        {/* <button type="button">
          Click
          </button> */}
          </div>
    </div>
  );
}

export default Employee;
