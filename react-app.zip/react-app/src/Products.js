import React from 'react'
import { useState,useEffect } from 'react';
import axios from 'axios';
import Navbarclass from './Navbarclass';
import Sidebar from './Sidebar';

function Products() {
    const[pkey,setkey]=useState([]);
  const [pdata, setData] = useState([]);

  useEffect(() => {
    axios.get("https://hub.dummyapis.com/products?noofRecords=10&idStarts=1001&currency=usd")
      .then((res) => { 
        setData(res.data);
    // keyf();
})
  },[])
//   const keyf=()=>{
//     var k=Object.keys(pdata[0])
//   setkey(k)}

//   const headers=({pkey})=>{
//       const c=React.Chidren.toArray(pkey).filter(Boolean)
//       return <th>{c}</th>
//   }
    return (
        <div>
          <Navbarclass/>
          <Sidebar/>
            {/* <headers></headers> */}
            {/* {JSON.stringify(data,null,2)} */}
            <table class="container">
                <th>
            <tr>
              <td>Id</td>
              <td>Product Name</td>
              <td>Product Description</td>
              <td>Price</td>
              
          </tr></th>
            {/* {key.map((i)=><th key={i}>{i}</th>)} */}
            {pdata.map((items)=>{
            return (
            <tr key={items}>
              <td>{items.id}</td>
              <td>{items.name}</td>
              <td>{items.description}</td>
              <td>{items.price}</td>
          </tr>
        )})} 
            </table>
        </div>
    )
}

export default Products
