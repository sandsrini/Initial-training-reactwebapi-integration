import axios from 'axios';
import React, { useEffect } from 'react'
import { useState } from 'react';
function Getapi() {
    const [data, setData] = useState();
    
    const getData = () => {
        axios.get("http://localhost:21645/api/userRegistration").then((res) => { setData(res.data) });
    }

    useEffect(()=>{
        //getData();
    })
    return (
        <div>
            <button onClick={()=>getData()}>Click</button>
            <br/>
{JSON.stringify(data)}
        </div>
    )
}

export default Getapi
