import axios from 'axios'
import React, { useEffect, useState } from 'react'

function Postapi() {

    const [userId, setid] = useState(0)
    const [Username, setUname] = useState("UserC")
    const [Password, setpwd] = useState("User@1234")
    const [Name, setname] = useState("UserC")
    const [Age, setage] = useState(70)
    const [Mobile, setmobile] = useState("9854466789")
    const [Email, setmail] = useState("user@gmaill.com")
    const [Address, setaddress] = useState("chennai")
    const [State, setstate] = useState("Tamil nadu")
    const [Pincode, setpincode] = useState("600053")
    const [Country, setcountry] = useState("India")
    const [data, setdata] = useState()

    useEffect(() => {
    post()
    
    }, [])

    const post=()=>{
    try{
    console.log(userId,Username,Password,Name,Age,Mobile,Email,Address,State,Pincode,Country)
    axios.post("http://localhost:21645/api/userRegistration/PostuserDetails",{Username,Password,Name,Age,Mobile,Email,Address,State,Pincode,Country}).
    then((req)=>{
        //setdata(req.body.data);
    console.log("post",req.data);
    })}
    catch(e){
        console.log("error",e)
    }
    }
    return (
        <div>
            postapi
        </div>
    )
}

export default Postapi
