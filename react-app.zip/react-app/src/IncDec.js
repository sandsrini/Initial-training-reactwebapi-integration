import logo from './logo.svg';
import './App.css';
import {useState} from 'react';
import reactDom from 'react-dom';

function IncDec() {
  const[x,add]=useState(0);
const[y,sub]=useState(x);
  return (
    <>
    <h1>
Main Bar</h1>
<h2>Incremental value = {x}</h2>
{/* <h2>Decremental value = {x}</h2> */}
<button onClick={()=>add(x+1)}>Increment </button>&nbsp;
<button onClick={()=>add(x-1)}>Decrement from current value </button>
<br></br>
<h2>Current value = {y}</h2>
<br/>
<button onClick={()=>sub(y-1)}>Decrement from 0</button>


    </>
  );
}

export default IncDec;
