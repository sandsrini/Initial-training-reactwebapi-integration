import React, { useState } from 'react'
import axios from 'axios';

function Deleteapi() {
    const [id,setId]=useState(0)
    const deleteData = () => {
        axios.delete("http://localhost:21645/api/userRegistration/"+id).then((req) => {console.log("deleteapi",req.data) });
    }
    return (
        <div>
            <input onChange={(e)=>{setId(e.target.value);
            console.log(e.target.value)}}></input>
            <button onClick={()=>{
                deleteData();
            }}>Delete</button>
            {/* {id} */}
        </div>
    )
}

export default Deleteapi
