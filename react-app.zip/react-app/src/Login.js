import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
// import {useNavigate} from 'react-router-dom'
import { useHistory } from 'react-router-dom'
import { useState, useEffect } from 'react'

function Login() {
  // const navigate=useNavigate();
  const history = useHistory();

  const userName = "u";
  const password = "User";

  const [uname, setuname] = useState("");
  const [pwd, setpwd] = useState("");

  const [unameError, setunameError] = useState("");
  const [pwdError, setpwdError] = useState("");
  const [status, setStatus] = useState(false);
  const [errmsg,setErrmsg]=useState("");

  const validate = (e) => {
    console.log(1)
    if (userName == uname && password == pwd) {

      setStatus(true);
      // await history.push({ pathname: '/dashboard', state: { status: status } });
      history.push( {pathname:'/employee'});

      console.log(2, uname, pwd, status);
    }
    else{
    setErrmsg("Incorrect Username or Password")
    }

  }
  const chkuname = () => {
    if (uname === "") {
      setunameError("Username is required");
    }
    else {
      setunameError("");
    }
  }

  const chkpwd = () => {
    if (pwd === "") {
      setpwdError("Password is required");
    }
    else {
      setpwdError("")

    }
  }

  return (
    <div class="hcenter">
      <div class="d-flex justify-content-center">
        <div class="login">

          <h1 class="text-center">Login to explore</h1>
          {/* </div> */}
          {/* <Login></Login> */}
          <form>

            <div class="m-5">
              <label class="m-2">Username</label>
              <input class="m-2" type="text" id="uname" onChange={(e) => {
                setuname(e.target.value);
                setunameError("")
              }}  />
              {/* onClick={(e) => { chkuname(e) }} */}
              </div>

            <div class="err">{unameError === "" ? "" : unameError}</div>
            
            <div class="m-5"><label class="m-2">Password</label>
              <input class="m-2" type="password" id="password" onChange={(e) => {
                setpwd(e.target.value);
                setpwdError("")
              }}  />
              {/* onClick={(e) => { chkpwd(e) }} */}
              </div>
            
            <div class="err">{pwdError === "" ? "" : pwdError}</div>
            <div> {errmsg===""?"":errmsg}</div>
            {/* <button type="submit" onClick={()=>navigate('Dashboard')}>Login</button> */}
            <div class="d-flex justify-content-center">
              
              <button class="text-white btn btn-success" type="submit" onFocus={(e) => {
                validate(e)
                chkuname(e);
                chkpwd(e)
              }}>Login</button></div>
          </form>
        </div>
      </div>

      {/* <App1/> */}

      {/* <link to="/Dashboard">hello
    {/* <buton type="submit" >Login</button> */}
      {/* onClick={()=>history.push({pathname:'/details',state:{ test : test  }})} */}
      {/* </litnk> */}
      {/* <Routes>
    <Route path="/Dashboard">
      <button type="submit" >Login</button></Route>
      </Routes> */}
    </div>
  );
}

export default Login;