import React from 'react'
import { useHistory } from 'react-router-dom'
//import {BrowserRouter,Switch,Route} from 'react-router-dom'
import Employee from './Employee'
import Products from './Products'

function Content() {
    const history=useHistory()
    return (
        <div>
            <button onClick={()=>{history.push("/logout")}}>Logout</button>
            {/* <BrowserRouter>
            <Switch>
                
                <Route exact pathname="/employee" component={Employee}></Route>
                <Route exact pathname="/products" component={Products}></Route>

            </Switch>
            </BrowserRouter> */}
        </div>
    )
}

export default Content
