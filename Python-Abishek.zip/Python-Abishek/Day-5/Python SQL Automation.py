import pandas as pd
from datetime import datetime
from pandas.io import sql
from plyer.facades import notification
import pyodbc, os
from plyer import notification


# Create a SQL connection
connection = pyodbc.connect(driver = '{ODBC Driver 17 for SQL Server}',
host = 'DESKTOP-NAKP5E5',database = 'Test',trusted_connection = 'yes')

# SQL Command to read the data
SQL_Query = "select * from dbo.SalesOrder"

# Getting the data from sql into pandas dataframe
# df = pd.read_sql(sql = SQL_Query, con = connection)
df = pd.read_sql(sql="select * from dbo.SalesOrder where Region ='South'",con=connection)

# Export the data on the desktop
df.to_csv(os.environ["userprofile"] + "\\Desktop\\SQL Data\\" + "SQL_SalesData_" + 
datetime.now().strftime("%d-%b-%Y %H-%M-%S") + ".csv",index=False)

#Display notification to user
from plyer import notification
notification.notify(title="SQL Report Status!!!",
message = f"Sales data has been load into excel. \
    \nTotalRows:{df.shape[0]}\nTotal Columns: {df.shape[1]}",
    timeout=10)

