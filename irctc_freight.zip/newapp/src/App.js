import logo from './logo.svg';
import './App.css';
import Freight from './Freight';
import Freightform from './form/Freightform';
import {BrowserRouter as Router,Link,Route,Switch} from 'react-router-dom'
import Update from './Update';
import Confirm from './Confirm';

function App() {
  return (
    <div>
  {/* <Freight/> */}
  <Router>
    <Switch>
    <Route path="/freightform" component={Freightform}/>
    
    <Route path="/update" component={Update}/>
    <Route path="" component={Freight}/>
    {/* default route should be at the end */}
    {/* <Route path="/confirm" component={Confirm}/> */}
    </Switch>
  </Router>
  </div>
  );
}

export default App;
