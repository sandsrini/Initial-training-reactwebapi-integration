import React from 'react'
import './form/Freightform.css'
import {useHistory, useLocation} from "react-router-dom";
import { useForm } from "react-hook-form";

function Update(props) {
    const history = useHistory();
    console.log(props)
    const location=useLocation();
    return (
        <div>
            <div>
            <body className="sanbodypart">
                <form className="sanformpart" >
                    <div>
                        <h1 className="sanheadingtxt">Update Your Freight Details</h1>
                    </div>
                    <div className="sanfs">
                
                        <div className="sanlin">
                            <label className="sanlabel1" for="fname">Freight Name</label>
                            <input className="sanin snaselect1" name="fname" value={location.state.fn} type="text" id="fname" placeholder="Freight Name"  />
                            
                        </div>
                        <div className="sanlin"><label className="sanlabel1" for="ftype">Type of Freight</label>

                            <select className="sanin sanselect1" name="ftype" value={location.state.ft} id="ftype" >
                                <option>Select</option>
                                <option value="Liquid-Volatile">Liquid-Volatile</option>
                                <option value="Liquid-Non-Volatile">Liquid-Non-Volatile</option>
                                <option value="Solid-Volatile">Solid-Volatile</option>
                                <option value="Solid-Non-Volatile">Solid-Non-Volatile</option>
                                <option value="Gas-Volatile">Gas-Volatile</option>
                                <option value="Gas-Non-Volatile">Gas-Non-Volatile</option>
                            </select>
                            
                        </div>
                        <div className="sanlin"><label className="sanlabel1" for="from">From</label>

                            <select className="sanin sanselect1" name="from" value={location.state.from} id="from" >
                                <option className="sanselect1">Select</option>
                                <option>NEW DELHI - NDLS</option>
                                <option>MGR CHENNAI CTL - MAS</option>
                                <option>HOWRAH JN - HWH</option>
                                <option>SECUNDERABAD JN - SC</option>
                                <option>PUNE JN - PUNE</option>
                                <option>CHENNAI EGMORE - MS</option>
                                <option>MUMBAI CENTRAL - MMCT</option>
                                <option>DELHI - DLI</option>
                                <option>MADURAI JN - MDU</option>
                                <option>TIRUCHCHIRAPALI - TPJ</option>
                            </select>
                            
                        </div>
                        <div className="sanlin"><label className="sanlabel1" for="to">To</label>

                            <select className="sanin sanselect1" name="to" value={location.state.to} id="to" >
                                <option className="sanselect1">Select</option>
                                <option>NEW DELHI - NDLS</option>
                                <option>MGR CHENNAI CTL - MAS</option>
                                <option>HOWRAH JN - HWH</option>
                                <option>SECUNDERABAD JN - SC</option>
                                <option>PUNE JN - PUNE</option>
                                <option>CHENNAI EGOMRE - MS</option>
                                <option>MUMBAI CENTRAL - MMCT</option>
                                <option>DELHI - DLI</option>
                                <option>MADURAI JN - MDU</option>
                                <option>TIRUCHCHIRAPALI - TPJ</option>
                            </select>
                            
                        </div>

                        <div className="sanlin"><label className="sanlabel1" for="departure">Departure</label>
                            <select className="sanin sanselect1"
                                name="departure" value={location.state.dep} id="departure" >
                                <option className="sanselect1">Departure</option>
                                <option>Early Morning(0-6)</option>
                                <option>Morning(6-15)</option>
                                <option>Mid Day(12-18)</option>
                                <option>Night(18-24)</option>
                            </select>
                            
                        </div>
                        <div className="sanlin"><label className="sanlabel1" for="arrival">Arrival</label>
                            <select
                                className="sanin sanselect1"
                                name="arrival" value={location.state.arrival}id="arrival" >
                                <option className="sanselect1">Arrival</option>
                                <option>Early Morning(0-6)</option>
                                <option>Morning(6-15)</option>
                                <option>Mid Day(12-18)</option>
                                <option>Night(18-24)</option>
                            </select>
                            
                        </div>
                        <div className="sansubmit"><button type="reset" className="sanbtncolor sanuppercase">Reset</button>
                            <button type="submit" className="sanbtncolor sanuppercase" >Save
                            </button>
                            <button type="button" className="sanbtncolor sanuppercase" onClick= {()=>history.push("")}>Cancel
                            </button>
                        </div>
                        {/* </div> onClick={(e) => validate(e)}*/}
                    </div>
                </form>
            </body>
        </div>
        </div>
    )
}

export default Update