import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { useHistory } from "react-router-dom";
import Update from './Update';
// import './form/Freightform.css'
import axios from 'axios'

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

export default function BasicModal(props) {
    const history1 = useHistory();
    console.log(props)
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    return (
        <p >
            <Button onClick={handleOpen} >Confirm</Button>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <Typography id="modal-modal-title" variant="h6" component="h2">
                        Text in a modal
                    </Typography>
                    <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                        <div>
                            <label>Freight Name:</label>
                            <input value={props.fn} disabled></input>
                        </div>
                        <div>
                            <label>Freight Type:</label>
                            <input value={props.ft} disabled></input>
                        </div>
                        <div>
                            <label>From:</label>
                            <input value={props.from} disabled></input>
                        </div>
                        <div>
                            <label>To:</label>
                            <input value={props.to} disabled></input>
                        </div>
                        <div><label>Departure:</label>
                            <input value={props.dep} disabled></input></div>
                        <div><label>Arrival:</label>
                            <input value={props.arrival} disabled></input></div>
                        <button type="button" onClick={() => history1.push("Update", { fn: props.fn, ft:props.ft, from: props.from, to: props.to, dep: props.dep, arrival: props.arrival })}>Edit</button>
                        {/* <Update data={props}/> */}
                    </Typography>
                </Box>
            </Modal>
        </p>
    );
}

