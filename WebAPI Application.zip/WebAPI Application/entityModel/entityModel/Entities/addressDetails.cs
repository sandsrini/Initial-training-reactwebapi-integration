﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace entityModel.Entities
{
    public class addressDetails
    {
        [Key]
        public int userAddressid { get; set; }
        
        public string Address { get; set; }
        
        public string Pincode { get; set; }
        
        public string State { get; set; }
        
        public string Country { get; set; }

        

        [ForeignKey("userdetails")]
        public int userId { get; set; }
        public userDetails userdetails { get; set; }
        
        //public int userId { get; set; }
    }
}
