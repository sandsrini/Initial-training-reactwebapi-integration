﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace entityModel.Entities
{
    public class userDetails
    {
        [Key]
        public int userId { get; set; }
        [Required]
        public string userName { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        //[Range(40,50)]
        public int Age { get; set; }
        [Required]
        public string Mobile { get; set; }
        [EmailAddress]
        public string Email { get; set; }

        public addressDetails address { get; set; }

        //public ICollection<addressDetails> userAddress { get; set; }
    }
}
