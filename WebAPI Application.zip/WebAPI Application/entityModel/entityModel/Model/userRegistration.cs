﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace entityModel.Model
{
    public class userRegistration
    {[Required]
    
        //[Remote("IsUserExists", "userRegistration", HttpMethod="post" ,ErrorMessage = "User Name already in use")]
        public string Username { get; set; }
        [Required]
        [DataType(DataType.Password)]
        
        public string Password { get; set; }
        public string Address { get; set; }
        [DataType(DataType.PostalCode)]
        

        public string Pincode { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        [Required]
        [RegularExpression(@"^[a-zA-Z''-'\s]{1,40}$",
         ErrorMessage = "Characters are not allowed.")]
        public string Name { get; set; }
        [Required]
        [Range(25,80)]
        public int Age { get; set; }  
        [Required]
        [DataType(DataType.PhoneNumber)]
        [StringLength(10,MinimumLength =10)]
        public string Mobile { get; set; }
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$",ErrorMessage ="Invalid email address")]
        public string Email { get; set; }
        public int userId { get; set;}
        public int useraddressid { get; set; }
    }
}
