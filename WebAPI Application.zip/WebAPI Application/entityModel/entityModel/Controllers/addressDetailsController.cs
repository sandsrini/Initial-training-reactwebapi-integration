﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using entityModel.Entities;
using entityModel.Model;

namespace entityModel.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class addressDetailsController : ControllerBase
    {
        private readonly userDbContext _context;

        public addressDetailsController(userDbContext context)
        {
            _context = context;
        }

        // GET: api/addressDetails
        [HttpGet]
        public async Task<ActionResult<IEnumerable<addressDetails>>> GetaddressDetails()
        {
            return await _context.addressDetails.ToListAsync();
        }

        // GET: api/addressDetails/5
        [HttpGet("{id}")]
        public async Task<ActionResult<addressDetails>> GetaddressDetails(int id)
        {
            var addressDetails = await _context.addressDetails.FindAsync(id);

            if (addressDetails == null)
            {
                return NotFound();
            }

            return addressDetails;
        }

        // PUT: api/addressDetails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("{id}")]
        //public async Task<IActionResult> PutaddressDetails(int id, addressDetails addressDetails)
        //{
        //    if (id != addressDetails.userAddressid)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(addressDetails).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!addressDetailsExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/addressDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<addressDetails>> PostaddressDetails(addressDetails addressDetails)
        {
            _context.addressDetails.Add(addressDetails);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetaddressDetails", new { id = addressDetails.userAddressid }, addressDetails);
        }

        // DELETE: api/addressDetails/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteaddressDetails(int id)
        //{
        //    var addressDetails = await _context.addressDetails.FindAsync(id);
        //    if (addressDetails == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.addressDetails.Remove(addressDetails);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        //private bool addressDetailsExists(int id)
        //{
        //    return _context.addressDetails.Any(e => e.userAddressid == id);
        //}
    }
}
