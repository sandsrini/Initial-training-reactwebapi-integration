﻿using entityModel.Entities;
using entityModel.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace entityModel.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userRegistrationController : ControllerBase
    {
        private readonly userDbContext _context;
        private readonly userDetails user1;
        private readonly addressDetails address1;

        public userRegistrationController(userDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IQueryable<Object> GetuserDetails()
        {
            //return await _context.userDetails.ToListAsync();
            var query = from b in _context.userDetails
                        join c in _context.addressDetails on b.userId equals c.userId into ps
                        from p in ps.DefaultIfEmpty()
                        select new
                        {
                            userId = b.userId,
                            userName = b.userName,
                            Password = b.Password,
                            Name = b.Name,
                            Age = b.Age,
                            mobile = b.Mobile,
                            mail = b.Email,

                            address = p.Address == null ? "Not filled" : p.Address,
                            state = p.State == null ? "Not filled" : p.State,
                            pincode = p.Pincode == null ? "Not filled" : p.Pincode,
                            country = p.Country == null ? "Not filled" : p.Country,
                            useraddressId=p.userAddressid==null?0:p.userAddressid
                        };
            return query;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutuserDetails(userRegistration userregistration)
        {
            //if (id != userDetails.userId)
            //{
            //    return BadRequest();
            //}



            //if (IsUserExistsforUpdate(userregistration.Username, userregistration.userId))
            //{
            //    return Ok("User name already exists");
            //}
            var user = _context.userDetails.Find(userregistration.userId);
            if (IsUserExists(userregistration.Username))
            {
                
                
                //var user = _context.userDetails.Where((x) => x.userName == userregistration.Username).FirstOrDefault();
                if (!(user.userName == userregistration.Username))
                {
                    return Ok("User name already exists");
                }
            }
            //var dto = new userDetails()
            //{
            user.userId = userregistration.userId;
            user.userName = userregistration.Username;
            user.Password = userregistration.Password;
            user.Name = userregistration.Name;
            user.Age = userregistration.Age;
            user.Mobile = userregistration.Mobile;
            user.Email = userregistration.Email;
            //};
            
            _context.Entry(user).State = EntityState.Modified;

            int userid = userregistration.userId;
            var ad = new addressDetails()
            {
                userId = userid,
                userAddressid=userregistration.useraddressid,
                Address = userregistration.Address,
                Pincode = userregistration.Pincode,
                State = userregistration.State,
                Country = userregistration.Country
            };
            if (userregistration.useraddressid == 0)
            {
                _context.addressDetails.Add(ad);
            }
            else
            {
                _context.Entry(ad).State = EntityState.Modified;
            }
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!userDetailsExists(userregistration.userId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpGet("{id}")]
        public  IQueryable<userRegistration> GetuserDetail(int id)
        {
            //var userDetails = await _context.userDetails.FindAsync(id);

            //if (userDetails == null)
            //{
            //    return NotFound();
            //}

            //return userDetails;
            var query= from b in _context.userDetails
                       //from c in _context.addressDetails
                   join c in _context.addressDetails
                   on b.userId equals c.userId where id==b.userId
                   select new userRegistration()
                   {
                       userId = b.userId,
                       Username = b.userName,
                       Password = b.Password,
                       Name = b.Name,
                       Age = b.Age,
                       Mobile = b.Mobile,
                       Email = b.Email,

                       Address = c.Address,
                       State = c.State,
                       Pincode = c.Pincode,
                       Country = c.Country,
                       useraddressid=c.userAddressid
                   };
            return query;
        }

        [HttpPost]
        [Route("PostuserDetails")]
        public async Task<ActionResult<userDetails>> PostuserDetails(userRegistration user)
        {
            //_context.userDetails.Add(userDetails);
            //await _context.SaveChangesAsync();
            //bool isUserExists = _context.userDetails.Any(x => x.userName.ToLower() == user.Username.ToLower());
            if (IsUserExists(user.Username))
            {
                return Ok("User name already exists");
            }
            else
            {

                var dto = new userDetails()
                {
                    userName = user.Username,
                    Password = user.Password,
                    Name = user.Name,
                    Age = user.Age,
                    Mobile = user.Mobile,
                    Email = user.Email
                };
                _context.userDetails.Add(dto);
                await _context.SaveChangesAsync();

                int userId = dto.userId;



                if (user.Address == "" || user.State == "" || user.Pincode == "" || user.Country == "")
                {
                    return Ok("Address table not filled");
                }
                else
                {
                    var address = new addressDetails()
                    {
                        Address = user.Address,
                        Pincode = user.Pincode,
                        State = user.State,
                        Country = user.Country,
                        userId = userId
                    };
                    _context.addressDetails.Add(address);
                    await _context.SaveChangesAsync();
                }
            }
            return Ok();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteuserDetails(int id)
        {//option1 delete - dbset add modelbuilder to cascade
            //var userDetails1 = await _context.userDetails.Include(x => x.address).Where(userId==id);
            var userDetails1 = await _context.userDetails.FindAsync(id);
            if (userDetails1 == null)
            {
                return NotFound();
            }

            Debug.WriteLine("userdetails",userDetails1);
            _context.userDetails.Remove(userDetails1);
            
            await _context.SaveChangesAsync();

            return NoContent();
        }
        private bool IsUserExists(string username)
        {
            if (_context.userDetails.Any(x => x.userName == username))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool IsUserExistsforUpdate(string username, int userid)
        {
            if (IsUserExists(username))
            {
                var dto = _context.userDetails.Find(userid);


                if (dto.userName==username)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }
        private bool userDetailsExists(int id)
        {
            return _context.userDetails.Any(e => e.userId == id);
        }
        private bool addressDetailsExists(int id)
        {
            return _context.addressDetails.Any(e => e.userId == id);
        }
    }
}

