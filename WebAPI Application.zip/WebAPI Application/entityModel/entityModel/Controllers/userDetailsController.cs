﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using entityModel.Entities;
using entityModel.Model;

namespace entityModel.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userDetailsController : ControllerBase
    {
        private readonly userDbContext _context;

        public userDetailsController(userDbContext context)
        {
            _context = context;
        }

        // GET: api/userDetails
        [HttpGet]
        public async Task<ActionResult<IEnumerable<userDetails>>> GetuserDetails()
        {
            return await _context.userDetails.ToListAsync();
        }

        // GET: api/userDetails/5
        [HttpGet("{id}")]
        public async Task<ActionResult<userDetails>> GetuserDetails(int id)
        {
            var userDetails = await _context.userDetails.FindAsync(id);

            if (userDetails == null)
            {
                return NotFound();
            }

            return userDetails;
        }

        // PUT: api/userDetails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("{id}")]
        //public async Task<IActionResult> PutuserDetails(int id, userDetails userDetails)
        //{
        //    if (id != userDetails.userId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(userDetails).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!userDetailsExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/userDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<userDetails>> PostuserDetails(userDetails userDetails)
        {
            _context.userDetails.Add(userDetails);
            await _context.SaveChangesAsync();

            //_context.Entry(userDetails).Reference(x => x.address).Load();

            //var dto = new userDetails()
            //{
            //    userId = userDetails.userId,
            //    userName = userDetails.userName,
            //   Password = userDetails.Password
            //};

            return CreatedAtAction("GetuserDetails", new { id = userDetails.userId }, userDetails);
        }

        // DELETE: api/userDetails/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteuserDetails(int id)
        //{
        //    var userDetails = await _context.userDetails.FindAsync(id);
        //    if (userDetails == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.userDetails.Remove(userDetails);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        //private bool userDetailsExists(int id)
        //{
        //    return _context.userDetails.Any(e => e.userId == id);
        //}
    }
}
