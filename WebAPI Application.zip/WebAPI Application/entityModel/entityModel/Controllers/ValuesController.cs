﻿using entityModel.Entities;
using entityModel.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace entityModel.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly userDbContext _context;
        private readonly userDetails user1;
        private readonly addressDetails address1;

        public ValuesController(userDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        //public async Task<IEnumerable<userDetails>> getuserdetails()
        public IQueryable<userDetails> getuserdetails()
        {
            //return await _context.userdetails.tolistasync();

            //return _context.userDetails.Include(i => i.userAddress);
            var books = from b in _context.userDetails
                        //from c in _context.addressDetails
                        //join c in _context.addressDetails
                        //on b.userId equals c.userId
                        select new userDetails()
                        {
                            userId = b.userId,
                            userName = b.userName,
                            Password = b.Password,
                            //doorNo=c.doorNo,
                            //streetname=c.streetName,
                            //locality=c.Locality
                        };

            return books;

        }
    }
}
