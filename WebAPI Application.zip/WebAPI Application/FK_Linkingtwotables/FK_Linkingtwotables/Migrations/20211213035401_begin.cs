﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FK_Linkingtwotables.Migrations
{
    public partial class begin : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "userDetails",
                columns: table => new
                {
                    userId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    userName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_userDetails", x => x.userId);
                });

            migrationBuilder.CreateTable(
                name: "userAddresses",
                columns: table => new
                {
                    userAddressid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    doorNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    streetName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Locality = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    userDetailsuserId = table.Column<int>(type: "int", nullable: true),
                    userId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_userAddresses", x => x.userAddressid);
                    table.ForeignKey(
                        name: "FK_userAddresses_userDetails_userDetailsuserId",
                        column: x => x.userDetailsuserId,
                        principalTable: "userDetails",
                        principalColumn: "userId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_userAddresses_userDetailsuserId",
                table: "userAddresses",
                column: "userDetailsuserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "userAddresses");

            migrationBuilder.DropTable(
                name: "userDetails");
        }
    }
}
