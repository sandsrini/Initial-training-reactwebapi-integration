﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FK_Linkingtwotables.Models
{
    public class userAddress
    {
        [Key]
        public int userAddressid { get; set; }
        public  string doorNo { get; set; }

        public string streetName { get; set; }

        public string Locality { get; set; }

        public string State { get; set; }

        public string Country { get; set; }


        public userDetails userDetails { get; set; }
        [ForeignKey("userId")]
        public int userId { get; set; }
        

    }
}
