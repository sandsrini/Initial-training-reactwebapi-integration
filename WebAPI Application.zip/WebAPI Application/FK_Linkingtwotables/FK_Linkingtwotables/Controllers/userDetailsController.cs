﻿using FK_Linkingtwotables.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FK_Linkingtwotables.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userDetailsController : ControllerBase
    {
        private readonly UserDbContext _context;
        public userDetailsController(UserDbContext con)
        {
            _context = con;

        }
        [HttpGet]
        public async Task<IEnumerable<userDetails>> GetAsync()
        {
            //return _context.userDetails.Include(c => c.userAddresses);
            var categories = await _context.userDetails.ToListAsync(); //query the Categories table
            var products = await _context.userAddresses.ToListAsync();      //query the products table
            var innerJoinQuery =
               from category in categories
               join prod in products on category.userId equals prod.userId
               select new { ProductName = prod.Country, Category = category.userName };

            return (IEnumerable<userDetails>)innerJoinQuery;
        }

        [HttpGet("id")]
        public async Task<IEnumerable<userDetails>> Getuserdetails(int id)
        {
            var user = await _context.userDetails.Include(c => c.userAddresses).Where(x => x.userId == id).FirstOrDefaultAsync();
            //var user = _context.userDetails.AsEnumerable();

            //if (user == null)
            //{s
            //    return NotFound();
            //}

            return user;
        }

            //var categories = _context.userDetails.ToList(); //query the Categories table
            //var products = _context.userAddresses.ToList();      //query the products table
            //var innerJoinQuery =
            //    from category in categories
            //    join prod in products on category.userId equals prod.userId
            //    select new { ProductName = prod.Country, Category = category.userName };

            //return await innerJoinQuery ;

            //            [HttpGet("id")]
            //            public Task<IEnumerable<userDetails>> Getuserdetails(int id)
            //            {
            //            var query = _context.userDetails
            //.Join(
            //    _context.userAddresses,
            //    customer => customer.userId,
            //    invoice => invoice.userDetails.userId,
            //    (customer, invoice) => new
            //    {
            //        InvoiceID = invoice.userAddressid,
            //        CustomerName = customer.userName + "" + customer.Password,
            //        InvoiceDate = invoice.Country
            //    }
            //).ToList();
            //            return query;
            //        }
        }
}
