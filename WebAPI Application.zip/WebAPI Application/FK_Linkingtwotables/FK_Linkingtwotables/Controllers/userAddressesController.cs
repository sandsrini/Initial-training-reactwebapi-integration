﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FK_Linkingtwotables.Models;

namespace FK_Linkingtwotables.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userAddressesController : ControllerBase
    {
        private readonly UserDbContext _context;

        public userAddressesController(UserDbContext context)
        {
            _context = context;
        }

        // GET: api/userAddresses
        [HttpGet]
        public IEnumerable<userAddress> GetuserAddresses()
        {
            return _context.userAddresses.Include(c => c.userDetails);
        }

        // GET: api/userAddresses/5
        [HttpGet("{id}")]
        public async Task<ActionResult<userAddress>> GetuserAddress(int id)
        {
            var userAddress = await _context.userAddresses.Include(c => c.userDetails).Where(e => e.userAddressid == id).FirstOrDefaultAsync();

            if (userAddress == null)
            {
                return NotFound();
            }

            return userAddress;
        }
    }
}
