﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace fk1.Models
{
    public partial class fk_dbContext : DbContext
    {
        public fk_dbContext()
        {
        }

        public fk_dbContext(DbContextOptions<fk_dbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<UserAddress> UserAddresses { get; set; }
        public virtual DbSet<UserDetail> UserDetails { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("data source=.;initial catalog=fk_db;integrated security=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<UserAddress>(entity =>
            {
                entity.ToTable("userAddresses");

                entity.HasIndex(e => e.UserId, "IX_userAddresses_userId");

                entity.Property(e => e.UserAddressid).HasColumnName("userAddressid");

                entity.Property(e => e.DoorNo).HasColumnName("doorNo");

                entity.Property(e => e.StreetName).HasColumnName("streetName");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserAddresses)
                    .HasForeignKey(d => d.UserId);
            });

            modelBuilder.Entity<UserDetail>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("userDetails");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.UserName).HasColumnName("userName");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
