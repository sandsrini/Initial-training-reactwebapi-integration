﻿using System;
using System.Collections.Generic;

#nullable disable

namespace fk1.Models
{
    public partial class UserAddress
    {
        public int UserAddressid { get; set; }
        public string DoorNo { get; set; }
        public string StreetName { get; set; }
        public string Locality { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public int UserId { get; set; }

        public virtual UserDetail User { get; set; }
    }
}
