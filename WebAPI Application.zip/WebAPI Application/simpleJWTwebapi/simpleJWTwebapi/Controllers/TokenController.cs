﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using simpleJWTwebapi.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace simpleJWTwebapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        public IConfiguration _configuration;
        public readonly UserDbContext _context;

        public TokenController(IConfiguration configuration,UserDbContext context)
        {
            _configuration = configuration;
            _context = context;
        }
        [HttpPost]
        public async Task<IActionResult> Post(UserRegistration userreg)
        {
            if (userreg != null && userreg.Username != null && userreg.Password != null)
            {
                var user = await GetUser(userreg.Username, userreg.Password);
                if (user != null)
                {
                    var Claims = new[]
                        {
                            new Claim(JwtRegisteredClaimNames.Sub,_configuration["JWT:Key"]),
                        new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat,DateTime.UtcNow.ToString()),
                        new Claim("Id", user.userId.ToString()),
                        new Claim("Username",user.Username.ToString()),
                        new Claim("Password",user.Password.ToString())
                        };

                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Key"]));
                    var signingkey = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(
                    issuer: _configuration["JWT:ValidIssuer"],
                    audience: _configuration["JWT:ValidAudience"],
                    expires: DateTime.Now.AddMinutes(2),
                    claims: Claims,
                    signingCredentials: signingkey);

                    return Ok(new
                    {
                        Status = "Success",
                        Message = "User logged in successfully",
                        token = new JwtSecurityTokenHandler().WriteToken(token),
                        expiration = token.ValidTo
                    }
                );
                }
                else
                {
                    return BadRequest("Invalid credentials");
                }
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<UserRegistration> GetUser(string username, string password)
        {
            return await _context.users.FirstOrDefaultAsync(x => x.Username == username && x.Password == password);
        }

    }
}
