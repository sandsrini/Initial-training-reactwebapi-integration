﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using simpleJWTwebapi.Models;

namespace simpleJWTwebapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserRegistrationsController : ControllerBase
    {
        private readonly UserDbContext _context;

        public UserRegistrationsController(UserDbContext context)
        {
            _context = context;
        }

        // GET: api/UserRegistrations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserRegistration>>> Getusers()
        {
            return await _context.users.ToListAsync();
        }

        // GET: api/UserRegistrations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<UserRegistration>> GetUserRegistration(int id)
        {
            var userRegistration = await _context.users.FindAsync(id);

            if (userRegistration == null)
            {
                return NotFound();
            }

            return userRegistration;
        }

        [HttpGet("GetUserDetails/{id}")]
        public async Task<ActionResult<UserRegistration>> GetUserDetails(int id)
        {
            var user = await _context.users.Include(auth => auth.UserDetails)
                //.Where(auth => auth.userId == id)
                .FirstOrDefaultAsync(i=>i.userId==id);

            if (user == null)
            {
                return NotFound();
            }

            return user;
        }

        // PUT: api/UserRegistrations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUserRegistration(int id, UserRegistration userRegistration)
        {
            if (id != userRegistration.userId)
            {
                return BadRequest();
            }

            _context.Entry(userRegistration).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserRegistrationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/UserRegistrations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<UserRegistration>> PostUserRegistration(UserRegistration userRegistration)
        {
            _context.users.Add(userRegistration);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUserRegistration", new { id = userRegistration.userId }, userRegistration);
        }

        // DELETE: api/UserRegistrations/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUserRegistration(int id)
        {
            var userRegistration = await _context.users.FindAsync(id);
            if (userRegistration == null)
            {
                return NotFound();
            }

            _context.users.Remove(userRegistration);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool UserRegistrationExists(int id)
        {
            return _context.users.Any(e => e.userId == id);
        }
    }
}
