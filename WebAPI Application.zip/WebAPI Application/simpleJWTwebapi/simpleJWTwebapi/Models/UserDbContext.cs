﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace simpleJWTwebapi.Models
{
    public class UserDbContext:DbContext
    {
     public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {

        }
        public virtual DbSet<UserRegistration> users { get; set; }
        public virtual DbSet<UserDetails> userdetails { get; set; }
    }
}
