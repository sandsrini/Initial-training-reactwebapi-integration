﻿using JWT_Tokens.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace JWT_Tokens.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly IConfiguration _configuration;

        public AuthenticateController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, IConfiguration configuration)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            _configuration = configuration;
        }
        // GET: api/<AuthenticateController>
        
        //[HttpGet]
        //[Authorize]
        //public async Task<IActionResult> get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET api/<AuthenticateController>/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        [HttpPost]
        [Route("Register")]

        public async Task<IActionResult> Register([FromBody] UserRegistration registration)
        {
            var userExists = await userManager.FindByNameAsync(registration.Username);

            if (userExists != null)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User Exists" });

            ApplicationUser users = new ApplicationUser()
            {
                
                SecurityStamp = Guid.NewGuid().ToString(),
                UserName = registration.Username,
                Email=registration.Email

            };

            var result = await userManager.CreateAsync(users,registration.Password);
            Debug.WriteLine("result", result);
            if(!result.Succeeded)
                //System.Diagnostics(result);      
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User Credentials failed! use strong password" });

            
            return Ok(new Response { Status = "Success", Message = "User registered succesfully" });
        }

        // POST api/<AuthenticateController>
        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> LoginCheck([FromBody] Login login)
        {
            var user = await userManager.FindByEmailAsync(login.Email);

            if(user!=null && await userManager.CheckPasswordAsync(user,login.Password))
            {
                var userRoles = await userManager.GetRolesAsync(user);
                var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name,user.UserName),
                new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                };

                foreach (var userRole in userRoles)
                {
                    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                }
                var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));

                var token = new JwtSecurityToken(
                    issuer:_configuration["JWT:ValidIssuer"],
                    audience:_configuration["JWT:ValidAudience"],
                    expires: DateTime.Now.AddMinutes(1),
                    claims: authClaims,
                    signingCredentials:new SigningCredentials(authSigningKey,SecurityAlgorithms.HmacSha256));

                return Ok(new
                {
                    Status = "Success", Message = "User logged in successfully",
                   token = new JwtSecurityTokenHandler().WriteToken(token),
                    expiration = token.ValidTo
                }
                );
            }

            return Unauthorized(new Response { Status = "Failed", Message = "Kindly check your Username or Password]" });
        }

        //// PUT api/<AuthenticateController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<AuthenticateController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
