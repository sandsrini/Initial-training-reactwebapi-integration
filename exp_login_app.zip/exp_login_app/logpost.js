var express=require("express")
var app=express()
const {MongoClient}=require("mongodb")
var url="mongodb://127.0.0.1:27017"
const cors=require("cors")
app.use(cors())

app.use(express.urlencoded({extended:true}))
app.use(express.json())
    
app.post("/",function(req,res){
        MongoClient.connect(url,function(err,conn){
        var db=conn.db("delta")
        db.collection("userlogin").find({name:req.body.name}).toArray(function(err,data){
            if(data.length===0){
                res.send("login_username_notexist_page")
            }
            else{
            if(data[0].pwd===req.body.pwd){
            res.send("login successfully")
            }
            else{
                res.send("Invalid username or password")
            }
            }
        })
        })
        })

app.listen(8080,function(req,res){
console.log("listening on 8080")
})