var express=require("express")
var app=express()

app.use(express.urlencoded({extended:true}))
app.use(express.json())

const {MongoClient}=require("mongodb")
var url="mongodb://127.0.0.1:27017"

var cookieParser=require("cookie-parser")
app.use(cookieParser())
var session=require("express-session")
app.use(session({secret:"shh! it is a secret"}))

app.set('view engine','pug')
app.set('views','./views')

app.get("/",function(req,res){
    res.sendFile(__dirname+"/homepage.html")
console.log(req.session)
})

app.get("/loginform",function(req,res){
    res.sendFile(__dirname+"/loginform.html")
})

app.get("/signup",function(req,res){
    res.sendFile(__dirname+"/reg.html")
})

app.post("/login",function(req,res){
    MongoClient.connect(url,function(err,conn){
        var db=conn.db("delta")
        db.collection("users").find({username:req.body.username}).toArray(function(err,data){
            if(data.length===0){
            res.sendFile(__dirname+"/login_username_notexist_page.html")
            }
        else{
        if(data[0].pwd===req.body.pwd){
            req.session.username=req.body.username
        req.session.pwd=req.body.pwd
        res.send("login sucessfully done")
        }
        else{res.send("Invalid username or password")}
        }
        })
    })
})
// app.get("/signup",function(req,res){
// res.sendFile(__dirname+"/reg.html")
// })
app.post("/register",function(req,res){
    if(req.body.pwd!=req.body.cpwd){
        res.redirect("/confirmerrpwd.html")
        }
    else{
    MongoClient.connect(url,function(err,conn){
    var db=conn.db("delta")
    db.collection("users").find({username:req.body.username}).toArray(function(err,data){
    if(data.length!=0){
    res.redirect("/usernameexistsform.html")
    }
    else{
    res.send("Resigtered")
    }
})
})
}})
function authenticate(req,res,next){
    if(req.session.username){
        MongoClient.connect(url,function(err,conn){
        var db=conn.db("delta")
        db.collection("users").find({username:req.session.username}).toArray(function(err,data){
            if(data.length===0){
                res.send("Username not exists")
            }
            else{
                if(data[0].pwd==req.session.pwd){
                next()
            }
                else{
                    res.send("Invalid username or password")
                }}})
            })}
    else{
    res.send("Resgister")
}}

app.get("/products",authenticate,function(req,res){
res.render("products",{user:req.session})
})

app.get("/services",authenticate,function(req,res){
    res.send("welcome")
})
app.listen(8000,function(req,res){
    console.log("listening on 8000")
})