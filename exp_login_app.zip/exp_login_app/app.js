var express=require("express")
var app=express()
const {MongoClient}=require("mongodb")
var url="mongodb://127.0.0.1:27017"
// var cors=require("cors")
// app.use(cors())

app.use(express.urlencoded({extended:true}))
app.use(express.json())

var cookieParser=require("cookie-parser")
app.use(cookieParser())

app.get("/signup",function(req,res){
res.sendFile(__dirname+"/reg.html")
})
app.get("/",function(req,res){
    res.sendFile(__dirname+"/homepage.html")
    res.clearCookie("username")
    res.clearCookie("pwd")
    })

app.get("/loginform",function(req,res)
{
res.sendFile(__dirname+"/loginform.html")
})

app.post("/login",function(req,res){
MongoClient.connect(url,function(err,conn){
var db=conn.db("delta")
db.collection("users").find({username:req.body.username}).toArray(function(err,data){
    if(data.length===0){
        res.sendFile(__dirname+"/login_username_notexist_page.html")
    }
    else{
    if(data[0].pwd===req.body.pwd){
    res.cookie("username",req.body.username)
    res.cookie("pwd",req.body.pwd)
    res.send("login successfully")
    }
    else{
        res.send("Invalid username or password")
    }
    }
})
})
})
function authenticate(req,res,next){
if(req.cookies.username){
    next();
}
else{
    res.sendFile(__dirname+"/loginform.html")
}
}
app.get("/products",authenticate,function(req,res){res.send("products")})
app.get("/services",authenticate,function(req,res){res.send("services")})
app.get("/aboutus",function(req,res){res.send("aboutus")})
app.post("/register",function(req,res){
        console.log("req fields",req.body)
        if(req.body.pwd!==req.body.cpwd){
            res.sendFile(__dirname+"/confirmerrpwd.html")
        }
        else{
            MongoClient.connect(url,function(err,conn){
                var db = conn.db("delta");
                db.collection("users").find({username:req.body.username})
                .toArray(function(err,data){
                    if(data.length===0){
                        db.collection('users').insertOne(req.body,function(err,data){
                            res.send(data)
                        })         
                    }
                    else{
                        res.sendFile(__dirname+"/usernameexistsform.html");          
                    }
                })
            })
        }
    })

app.listen(8080,function(req,res){
console.log("listening on 8080")
})