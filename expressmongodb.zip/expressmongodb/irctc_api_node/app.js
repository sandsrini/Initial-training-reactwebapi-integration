var express=require("express");
var router=express();
var irctc_freight=require("./irctc_freight")

router.use(express.urlencoded({extended:true}));
router.use(express.json());

router.get("/",function(req,res){
    // res.sendFile(__dirname+"/homepage.html")
    res.send("hello")
})
router.use("/irctc_freight",irctc_freight)

router.listen(7000,function(){
    console.log("Listening on 7000")
})

router.use(express.static(__dirname+"/open"))

