var express=require("express")
var app=express();
var studs=[]
const {MongoClient}=require("mongodb");

var url="mongodb://127.0.0.1:27017"
var cors=require("cors")
app.use(cors())

app.use(express.urlencoded({extended:true}));
app.use(express.json());

app.set('view engine','pug');
app.set('views','./views');

app.get("/view",function(req,res){
MongoClient.connect(url,function(err,conn){
var db=conn.db("delta")
db.collection("students").find().toArray(function(err,data){
res.send(data);
console.log("data",data)
// studs.push(data);
})
})
})

// app.get("/apppug",function(req,res){
// res.render("appmongopug",{allstuds:studs})
// })

app.listen(8080,function(){
    console.log("listening on 8080")
})